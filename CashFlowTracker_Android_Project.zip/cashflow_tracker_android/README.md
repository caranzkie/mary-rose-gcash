# CashFlow Tracker — Android project

A mobile-first, offline record keeper for Cash In, Cash Out, service-fee earnings, and business expenses. It is an independent bookkeeping app and is not affiliated with GCash.

## Features

- Record Cash In and Cash Out transactions.
- Enter the actual service fee earned on each transaction.
- Record business expenses.
- Automatically calculate total Cash In, total Cash Out, service-fee earnings, expenses, and net income.
- Filter summaries by today, this week, this month, or all time.
- Search, edit, and delete records.
- Export a JSON backup or CSV transaction report; import a JSON backup.
- Stores records locally on the device. No GCash login, PIN, OTP, wallet connection, or server sync.

## Build an APK in Android Studio

1. Install Android Studio with Android SDK Platform 35 and a JDK 17 runtime.
2. Open this project folder (`cashflow_tracker_android`) in Android Studio.
3. Allow Gradle to sync and install any requested Android SDK components.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will generate the debug APK at:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Transfer that APK to your Android phone and install it. You may need to allow installation from that file manager.

The project uses Android Gradle Plugin 8.7.3 and Kotlin 2.0.21. Android Studio may download the matching Gradle distribution during sync.

## Data and income calculation

- **Total Cash In / Total Cash Out:** transaction principal amounts, tracked separately.
- **Service Fee Earnings:** the sum of fees entered on Cash In and Cash Out records.
- **Net Income:** Service Fee Earnings minus recorded business expenses.

The transaction principal is not counted as income. Fees are entered manually because rates can vary by transaction or operator.

## Important

This app does not process payments or connect to a GCash account. It is only for manually recording transactions. Records are stored in the app's local WebView storage; export a backup before clearing app data, uninstalling, or changing devices. The app does not sync records to the cloud.
